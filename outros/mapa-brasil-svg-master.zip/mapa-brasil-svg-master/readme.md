# Mapa do Brasil em SVG

![Preview](https://raw.github.com/luisdalmolin/mapa-brasil-svg/master/mapa-brasil-svg.jpg)

Todos os estados possuem o ID com seus respectivos UF's, por exemplo **RS** ou **SP**.

### Cores

Para customizar as cores do mapa, edite o bloco `<style>` contido dentro do arquivo `mapa.html`.

### Licença

[MIT License](http://luisdalmolin.mit-license.org/) © Luis Dalmolin